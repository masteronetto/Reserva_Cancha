package com.usuarioservice.usuarioservice.repository;

import com.usuarioservice.usuarioservice.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
}
